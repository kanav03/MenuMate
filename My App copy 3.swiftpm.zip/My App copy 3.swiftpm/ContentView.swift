import SwiftUI
import AVFoundation
import Vision
import VisionKit
import Speech

struct CustomColors {
    static let primaryOrange = Color.orange
    static let darkOrange = Color(red: 0.9, green: 0.4, blue: 0.0)
    static let lightOrange = Color.orange.opacity(0.1)
    static let accentOrange = Color.orange.opacity(0.2)
}

struct ContentView: View {
    @State private var selectedImage: UIImage? = nil
    @State private var menuItems: [String] = []
    @State private var selectedItems: [String] = []
    @State private var orderSummary: String = ""
    @State private var isScanning = false
    @State private var showOrderSummary = false
    @State private var showSpeechInput = false
    @State private var recognizedSpeech = ""
    @State private var awaitingConfirmation = false
    @State private var lastRecognizedItem: String = ""
    @State private var voiceInputItem: String = ""
    @State private var showVoiceConfirmation = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 15) {
                // Scanned Menu Image
                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 180)
                        .cornerRadius(12)
                        .shadow(radius: 5)
                } else {
                    Button(action: { isScanning = true }) {
                        Label("Scan Menu", systemImage: "camera.fill")
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(CustomColors.darkOrange)
                            .foregroundColor(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .shadow(radius: 5)
                    }
                    .padding(.horizontal)
                }
                
                // Menu Items List
                VStack(alignment: .leading, spacing: 8) {
                    Text("Select Your Order:")
                        .font(.title2)
                        .bold()
                        .padding(.horizontal)
                    
                    ScrollView {
                        LazyVStack(spacing: 8) {
                            ForEach(menuItems.indices, id: \.self) { index in
                                let item = menuItems[index]
                                Button(action: { toggleSelection(item) }) {
                                    HStack {
                                        Text(item)
                                            .font(.body)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .multilineTextAlignment(.leading)
                                        
                                        Image(systemName: selectedItems.contains(item) ? "checkmark.circle.fill" : "circle")
                                            .foregroundColor(selectedItems.contains(item) ? CustomColors.darkOrange : .gray)
                                            .imageScale(.large)
                                    }
                                    .padding(.vertical, 12)
                                    .padding(.horizontal, 16)
                                    .background(CustomColors.lightOrange)
                                    .cornerRadius(10)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    .frame(maxHeight: .infinity)
                }
                
                // Bottom Action Buttons
                VStack(spacing: 12) {
                    Button(action: { showOrderSummary = true }) {
                        Label("Generate Order Card", systemImage: "doc.fill")
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(CustomColors.darkOrange)
                            .foregroundColor(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    
                    Button(action: {
                        showSpeechInput.toggle()
                        if !showSpeechInput {
                            recognizedSpeech = ""
                            awaitingConfirmation = false
                            lastRecognizedItem = ""
                        }
                    }) {
                        Label("Ask a Question", systemImage: "mic.fill")
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(CustomColors.primaryOrange)
                            .foregroundColor(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 8)
                .shadow(radius: 3)
                
                // Speech Recognition UI
                if showSpeechInput {
                    VStack {
                        SpeechRecognizer(recognizedText: $recognizedSpeech, 
                                         awaitingConfirmation: $awaitingConfirmation, 
                                         lastRecognizedItem: $lastRecognizedItem)
                        .frame(height: 80)
                        
                        if awaitingConfirmation {
                            Text("Would you like to add \(lastRecognizedItem)?")
                                .padding(.top)
                            HStack(spacing: 20) {
                                Button("Yes") {
                                    if !lastRecognizedItem.isEmpty {
                                        voiceInputItem = lastRecognizedItem
                                        showVoiceConfirmation = true
                                        awaitingConfirmation = false
                                        showSpeechInput = false
                                    }
                                }
                                .padding(.horizontal, 30)
                                .padding(.vertical, 8)
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                                
                                Button("No") {
                                    awaitingConfirmation = false
                                }
                                .padding(.horizontal, 30)
                                .padding(.vertical, 8)
                                .background(Color.red)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                            }
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
            .navigationTitle("Menu Buddy")
            .sheet(isPresented: $showOrderSummary) {
                OrderSummaryView(selectedItems: selectedItems)
            }
            .sheet(isPresented: $isScanning) {
                ScannerView(image: $selectedImage, menuItems: $menuItems)
            }
            .sheet(isPresented: $showVoiceConfirmation) {
                VoiceConfirmationView(item: voiceInputItem, selectedItems: $selectedItems, isPresented: $showVoiceConfirmation, showOrderSummary: $showOrderSummary)
            }
        }
    }
    
    private func toggleSelection(_ item: String) {
        if let index = selectedItems.firstIndex(of: item) {
            selectedItems.remove(at: index)
        } else {
            selectedItems.append(item)
        }
    }
}

// MARK: - Order Summary Page
struct OrderSummaryView: View {
    let selectedItems: [String]
    @Environment(\.dismiss) private var dismiss
    @State private var showCheeseQuestion = true
    @State private var extraCheese = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 15) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 15) {
                        // Voice Ordered Items Section - Move this before cheese question
                        if !selectedItems.isEmpty {
                            Section(header: 
                                        Text("Your Order")
                                .font(.title)
                                .bold()
                                .padding(.top)
                            ) {
                                ForEach(selectedItems, id: \.self) { item in
                                    OrderItemCard(item: item)
                                }
                                
                                // Show Extra Cheese confirmation if selected
                                if !showCheeseQuestion && extraCheese {
                                    OrderItemCard(item: "Extra Cheese Added")
                                }
                            }
                            .padding(.bottom, 20)
                        }
                        
                        // Extra Cheese Question - Move this after order items
                        if showCheeseQuestion {
                            VStack(spacing: 10) {
                                Text("Would you like extra cheese?")
                                    .font(.headline)
                                    .padding(.top)
                                
                                HStack(spacing: 20) {
                                    Button("Yes") {
                                        extraCheese = true
                                        showCheeseQuestion = false
                                    }
                                    .padding()
                                    .frame(width: 100)
                                    .background(Color.green)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    
                                    Button("No") {
                                        extraCheese = false
                                        showCheeseQuestion = false
                                    }
                                    .padding()
                                    .frame(width: 100)
                                    .background(Color.red)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                }
                            }
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(15)
                        }
                        
                        // Order Summary
                        OrderTotalSection(items: selectedItems, hasExtraCheese: extraCheese)
                    }
                    .padding()
                }
                
                // Bottom Buttons
                BottomButtons(dismiss: dismiss)
            }
            .navigationTitle("Order Summary")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// Helper Views
struct OrderItemCard: View {
    let item: String
    
    var body: some View {
        HStack {
            Text(item)
                .font(.title3)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
            
            Image(systemName: "checkmark.circle.fill")
                .foregroundColor(CustomColors.darkOrange)
                .padding(.trailing)
        }
        .background(CustomColors.accentOrange)
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.2), radius: 3)
    }
}

struct EmptyOrderView: View {
    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: "cart")
                .font(.system(size: 50))
                .foregroundColor(.gray)
            Text("No items in your order")
                .font(.headline)
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

struct OrderTotalSection: View {
    let items: [String]
    let hasExtraCheese: Bool
    
    var body: some View {
        if !items.isEmpty {
            VStack(spacing: 10) {
                Divider()
                HStack {
                    Text("Total Items:")
                        .font(.headline)
                    Spacer()
                    Text("\(items.count + (hasExtraCheese ? 1 : 0))")
                        .font(.title3)
                        .bold()
                }
                Group {
                    if hasExtraCheese {
                        HStack {
                            Text("Extra Cheese:")
                                .font(.headline)
                                .foregroundColor(.green)
                            Spacer()
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

struct BottomButtons: View {
    let dismiss: DismissAction
    
    var body: some View {
        HStack(spacing: 15) {
            Button(action: { dismiss() }) {
                Text("Close")
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.gray)
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
            
            Button(action: {
                // Add functionality for confirming order
            }) {
                Text("Confirm Order")
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(CustomColors.darkOrange)
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
        }
        .padding()
        .background(Color.white)
        .shadow(radius: 5, y: -5)
    }
}

// MARK: - OCR Scanner for Menu
struct ScannerView: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Binding var menuItems: [String]
    
    func makeUIViewController(context: Context) -> VNDocumentCameraViewController {
        let scannerVC = VNDocumentCameraViewController()
        scannerVC.delegate = context.coordinator
        return scannerVC
    }
    
    func updateUIViewController(_ uiViewController: VNDocumentCameraViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(self)
    }
    
    class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        var parent: ScannerView
        
        init(_ parent: ScannerView) {
            self.parent = parent
        }
        
        func documentCameraViewControllerDidFinish(_ controller: VNDocumentCameraViewController) {
            controller.dismiss(animated: true)
        }
        
        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
            let scannedImage = scan.imageOfPage(at: 0)
            parent.image = scannedImage
            extractText(from: scannedImage)
            
            controller.dismiss(animated: true)
        }
        
        private func extractText(from image: UIImage) {
            guard let cgImage = image.cgImage else { return }
            let request = VNRecognizeTextRequest { request, error in
                guard let observations = request.results as? [VNRecognizedTextObservation], error == nil else { return }
                let recognizedStrings = observations.compactMap { $0.topCandidates(1).first?.string }
                DispatchQueue.main.async {
                    self.parent.menuItems = recognizedStrings
                }
            }
            let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            try? requestHandler.perform([request])
        }
    }
}

// MARK: - Speech Recognition
struct SpeechRecognizer: UIViewControllerRepresentable {
    @Binding var recognizedText: String
    @Binding var awaitingConfirmation: Bool
    @Binding var lastRecognizedItem: String
    
    func makeUIViewController(context: Context) -> SpeechViewController {
        return SpeechViewController(recognizedText: $recognizedText, awaitingConfirmation: $awaitingConfirmation, lastRecognizedItem: $lastRecognizedItem)
    }
    
    func updateUIViewController(_ uiViewController: SpeechViewController, context: Context) {}
}

class SpeechViewController: UIViewController, SFSpeechRecognizerDelegate {
    var recognizedText: Binding<String>
    var awaitingConfirmation: Binding<Bool>
    var lastRecognizedItem: Binding<String>
    let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    let audioEngine = AVAudioEngine()
    let request = SFSpeechAudioBufferRecognitionRequest()
    var recognitionTask: SFSpeechRecognitionTask?
    
    init(recognizedText: Binding<String>, awaitingConfirmation: Binding<Bool>, lastRecognizedItem: Binding<String>) {
        self.recognizedText = recognizedText
        self.awaitingConfirmation = awaitingConfirmation
        self.lastRecognizedItem = lastRecognizedItem
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        speechRecognizer?.delegate = self
        requestSpeechAuthorization()
    }
    
    private func requestSpeechAuthorization() {
        SFSpeechRecognizer.requestAuthorization { status in
            DispatchQueue.main.async {
                switch status {
                case .authorized:
                    self.startRecording()
                default:
                    print("Speech recognition authorization denied")
                }
            }
        }
    }
    
    private func startRecording() {
        // Cancel any existing recognition task
        recognitionTask?.cancel()
        recognitionTask = nil
        
        // Configure audio session
        let audioSession = AVAudioSession.sharedInstance()
        try? audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try? audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        
        // Configure audio engine and recognition
        let node = audioEngine.inputNode
        let recordingFormat = node.outputFormat(forBus: 0)
        
        node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.request.append(buffer)
        }
        
        audioEngine.prepare()
        try? audioEngine.start()
        
        recognitionTask = speechRecognizer?.recognitionTask(with: request) { [weak self] result, error in
            guard let self = self else { return }
            
            if let result = result {
                let recognizedText = result.bestTranscription.formattedString
                DispatchQueue.main.async {
                    self.recognizedText.wrappedValue = recognizedText
                    
                    // If we have a meaningful recognition, trigger the confirmation dialog
                    if !recognizedText.isEmpty {
                        self.lastRecognizedItem.wrappedValue = recognizedText
                        self.awaitingConfirmation.wrappedValue = true
                        
                        // Stop recording after getting a result
                        self.audioEngine.stop()
                        node.removeTap(onBus: 0)
                        self.recognitionTask?.cancel()
                        self.recognitionTask = nil
                    }
                }
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionTask?.cancel()
        recognitionTask = nil
    }
}

// Add new view for voice input confirmation
struct VoiceConfirmationView: View {
    let item: String
    @Binding var selectedItems: [String]
    @Binding var isPresented: Bool
    @Binding var showOrderSummary: Bool
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Would you like \(item)?")
                    .font(.title2)
                    .padding()
                
                HStack(spacing: 20) {
                    Button("Yes") {
                        selectedItems.append(item)
                        isPresented = false
                        showOrderSummary = true
                    }
                    .padding()
                    .frame(width: 120)
                    .background(CustomColors.darkOrange)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    
                    Button("No") {
                        isPresented = false
                    }
                    .padding()
                    .frame(width: 120)
                    .background(Color.gray)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
            }
            .navigationTitle("Confirm Order")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

