//
//  menulastpllApp.swift
//  menulastpll
//
//  Created by admin34 on 23/02/25.
//

import SwiftUI

@main
struct menulastpllApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
